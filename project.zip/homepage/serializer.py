from rest_framework import serializers
from .models import CustomerModel,SliderImage
class CustomerSerilizer(serializers.ModelSerializer):
    class Meta:
        model=CustomerModel
        fields ='__all__'


class ImageSerializer(serializers.ModelSerializer):
    class Meta:
        model=SliderImage
        fields='__all__'
