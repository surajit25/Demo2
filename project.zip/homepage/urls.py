from django.contrib import admin
from django.urls import path, include
from . import views
from rest_framework import routers
from .views import CustomerViweset, SliderViewset

router = routers.DefaultRouter();
router.register(r'customer', CustomerViweset)
router.register(r'sliderimage', SliderViewset)

urlpatterns = router.urls
