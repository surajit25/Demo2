from django.db import models

# Create your models here.

class CustomerModel(models.Model):
    name = models.CharField(max_length=30,default='')
    email = models.CharField(max_length=50,default='')
    age = models.IntegerField(default='')
    interest = models.CharField(max_length=30,default='')
    review = models.TextField(max_length=100,default='')

class SliderImage(models.Model):
    name = models.CharField(max_length=20,default='');
    image = models.ImageField(upload_to='pics')
    description =models.TextField(max_length=100,default='')