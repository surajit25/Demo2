from django.shortcuts import render
from django.http import HttpResponse
from django.views import View
# Create your views here.
from rest_framework import viewsets
from .serializer import CustomerSerilizer, ImageSerializer
from .models import CustomerModel, SliderImage


class CustomerViweset(viewsets.ModelViewSet):
    serializer_class = CustomerSerilizer
    queryset = CustomerModel.objects.all()


class SliderViewset(viewsets.ModelViewSet):
    serializer_class = ImageSerializer
    queryset = SliderImage.objects.all()
