from django.contrib import admin

# Register your models here.
from .models import CustomerModel


class AdminCustomer(admin.ModelAdmin):
    list_display = ['name', 'email', 'interest', 'review']


admin.site.register(CustomerModel, AdminCustomer)
